function FindProxyForURL(url, host) {
    let data = ["taobao.com", "alipayobjects.com", "360buyimg.com", "jd.com", "taobao.org", "zhihu.com", "zhimg.com", "baidu.com", "aliyun.com", "tencent.com", "gmail.com", "huaweicloud.com", "tanx.com", "tmall.com", "zhifu.com", "alipay.com", "alicdn.com", "mmstat.com"];
    for (let i = 0; i < data.length; i++) {
        if (host.indexOf(data[i]) == 0 || host.indexOf("." + data[i]) != -1) {
            return "DIRECT";
        }
    }
    return "HTTPS xxx.xxxx.xxx:443";
}